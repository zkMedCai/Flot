package com.salmoit.yugiohwatcher;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public final class SiteChecker {
    private static final OkHttpClient CLIENT = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build();

    private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 14; Mobile) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0 Mobile Safari/537.36";

    private static final Pattern PRICE_PATTERN = Pattern.compile(
            "(?:[¥￥]\\s*|JPY\\s*)([0-9][0-9,]{2,})|([0-9][0-9,]{2,})\\s*(?:円|yen)",
            Pattern.CASE_INSENSITIVE
    );

    private SiteChecker() {}

    public static CheckResult check(Site site, int maxYen) {
        try {
            Request request = new Request.Builder()
                    .url(site.url)
                    .header("User-Agent", USER_AGENT)
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .header("Accept-Language", "it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7,ja;q=0.6")
                    .build();

            try (Response response = CLIENT.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    return new CheckResult(site, CheckResult.ERROR, null, "", "HTTP " + response.code());
                }

                String html = response.body().string();
                Document doc = Jsoup.parse(html, site.url);
                String title = doc.title() == null ? "" : doc.title().trim();
                String text = doc.text();
                String merged = (title + " " + text).replace('\u00A0', ' ');

                boolean target = containsTargetKeyword(merged);
                boolean soldOut = containsAny(merged, new String[]{
                        "sold out", "out of stock", "notify me when available", "unavailable",
                        "品切れ", "在庫なし", "売り切れ", "売切れ", "完売", "販売終了", "入荷待ち",
                        "在庫切れ", "在庫 なし", "申し訳ございません。品切れ中です"
                });
                boolean preorder = containsAny(merged, new String[]{
                        "pre-order", "preorder", "pre order", "presale", "pre-sale", "予約", "予約販売", "予約受付", "発売予定"
                });

                Integer price = extractLowestReasonablePrice(merged);

                if (!target) {
                    return new CheckResult(site, CheckResult.NOT_FOUND, price, title, "Non vedo le keyword del prodotto nella pagina.");
                }

                if (soldOut) {
                    return new CheckResult(site, CheckResult.SOLD_OUT, price, title, "La pagina sembra indicare prodotto non disponibile o sold out.");
                }

                if (price != null) {
                    if (price <= maxYen) {
                        String note = preorder ? "Keyword preorder trovata e prezzo sotto soglia." : "Prezzo sotto soglia: apri e verifica il box sigillato.";
                        return new CheckResult(site, CheckResult.GOOD, price, title, note);
                    }
                    return new CheckResult(site, CheckResult.EXPENSIVE, price, title, "Prodotto trovato, ma sopra la soglia impostata.");
                }

                if (preorder) {
                    return new CheckResult(site, CheckResult.MAYBE, null, title, "Keyword preorder trovata, ma non riesco a leggere il prezzo.");
                }

                return new CheckResult(site, CheckResult.MAYBE, null, title, "Prodotto trovato, ma disponibilità/prezzo non chiari.");
            }
        } catch (Exception e) {
            return new CheckResult(site, CheckResult.ERROR, null, "", e.getClass().getSimpleName() + ": " + safeMessage(e));
        }
    }

    private static String safeMessage(Exception e) {
        return e.getMessage() == null ? "" : e.getMessage();
    }

    private static boolean containsTargetKeyword(String text) {
        String u = text.toUpperCase(Locale.ROOT);
        return u.contains("ORIGINAL ARTWORK COLLECTION")
                || text.contains("オリジナルアートワーク")
                || text.contains("遊戯王 ORIGINAL ARTWORK")
                || text.contains("遊☆戯☆王 ORIGINAL ARTWORK")
                || text.contains("原作絵")
                || text.contains("MANGA-STYLE")
                || text.contains("MANGA STYLE");
    }

    private static boolean containsAny(String text, String[] needles) {
        String lower = text.toLowerCase(Locale.ROOT);
        for (String needle : needles) {
            String n = needle.toLowerCase(Locale.ROOT);
            if (lower.contains(n)) return true;
        }
        return false;
    }

    private static Integer extractLowestReasonablePrice(String text) {
        Matcher matcher = PRICE_PATTERN.matcher(text);
        List<Integer> prices = new ArrayList<>();
        while (matcher.find()) {
            String raw = matcher.group(1) != null ? matcher.group(1) : matcher.group(2);
            if (raw == null) continue;
            try {
                int value = Integer.parseInt(raw.replace(",", ""));
                // Avoid noise: pack retail is 396 yen; focus on box/bundle-like prices. Retail box target is 5,940 yen.
                if (value >= 3000 && value <= 500000) {
                    prices.add(value);
                }
            } catch (NumberFormatException ignored) {
            }
        }
        if (prices.isEmpty()) return null;
        int min = prices.get(0);
        for (int p : prices) min = Math.min(min, p);
        return min;
    }
}
