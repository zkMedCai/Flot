package com.salmoit.yugiohwatcher;

public final class Site {
    public final String name;
    public final String url;

    public Site(String name, String url) {
        this.name = name;
        this.url = url;
    }
}
