package com.salmoit.yugiohwatcher;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public final class SiteChecker {
    private static final OkHttpClient CLIENT = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build();

    private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 14; Mobile) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0 Mobile Safari/537.36";

    private static final Pattern PRICE_PATTERN = Pattern.compile(
            "(?:[¥￥]\\s*|JPY\\s*)([0-9][0-9,]{2,})|([0-9][0-9,]{2,})\\s*(?:円|yen)",
            Pattern.CASE_INSENSITIVE
    );

    private SiteChecker() {}

    public static CheckResult check(Site site, int maxYen) {
        try {
            Request request = new Request.Builder()
                    .url(site.url)
                    .header("User-Agent", USER_AGENT)
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .header("Accept-Language", "it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7,ja;q=0.6")
                    .build();

            try (Response response = CLIENT.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    return new CheckResult(site, CheckResult.ERROR, null, "", "HTTP " + response.code());
                }

                String html = response.body().string();
                Document doc = Jsoup.parse(html, site.url);
                String title = doc.title() == null ? "" : normalize(doc.title());

                // Search pages are noisy: the page title/search box can contain the target keywords
                // while prices may belong to unrelated products. On these pages we only trust prices
                // found inside a product card/link whose own text contains the target product name.
                if (isSearchPage(site.url)) {
                    return checkSearchPage(site, maxYen, doc, title);
                }

                String text = doc.text();
                String merged = normalize(title + " " + text);

                boolean target = containsTargetKeyword(merged);
                boolean soldOut = containsAny(merged, new String[]{
                        "sold out", "out of stock", "notify me when available", "unavailable",
                        "品切れ", "在庫なし", "売り切れ", "売切れ", "完売", "販売終了", "入荷待ち",
                        "在庫切れ", "在庫 なし", "申し訳ございません。品切れ中です"
                });
                boolean preorder = containsAny(merged, new String[]{
                        "pre-order", "preorder", "pre order", "presale", "pre-sale", "予約", "予約販売", "予約受付", "発売予定"
                });

                Integer price = extractLowestReasonablePrice(merged);

                if (!target) {
                    return new CheckResult(site, CheckResult.NOT_FOUND, price, title, "Non vedo le keyword del prodotto nella pagina.");
                }

                if (soldOut) {
                    return new CheckResult(site, CheckResult.SOLD_OUT, price, title, "La pagina sembra indicare prodotto non disponibile o sold out.");
                }

                if (price != null) {
                    if (price <= maxYen) {
                        String note = preorder ? "Keyword preorder trovata e prezzo sotto soglia." : "Prezzo sotto soglia: apri e verifica il box sigillato.";
                        return new CheckResult(site, CheckResult.GOOD, price, title, note);
                    }
                    return new CheckResult(site, CheckResult.EXPENSIVE, price, title, "Prodotto trovato, ma sopra la soglia impostata.");
                }

                if (preorder) {
                    return new CheckResult(site, CheckResult.MAYBE, null, title, "Keyword preorder trovata, ma non riesco a leggere il prezzo.");
                }

                return new CheckResult(site, CheckResult.MAYBE, null, title, "Prodotto trovato, ma disponibilità/prezzo non chiari.");
            }
        } catch (Exception e) {
            return new CheckResult(site, CheckResult.ERROR, null, "", e.getClass().getSimpleName() + ": " + safeMessage(e));
        }
    }

    private static CheckResult checkSearchPage(Site site, int maxYen, Document doc, String pageTitle) {
        List<Candidate> candidates = findSearchCandidates(doc);
        if (candidates.isEmpty()) {
            return new CheckResult(site, CheckResult.NOT_FOUND, null, pageTitle,
                    "Pagina di ricerca: nessun risultato con titolo esatto del prodotto. Evito alert falsi.");
        }

        Candidate bestPriced = null;
        Candidate firstWithoutPrice = null;
        for (Candidate c : candidates) {
            if (c.priceYen == null) {
                if (firstWithoutPrice == null) firstWithoutPrice = c;
                continue;
            }
            if (bestPriced == null || c.priceYen < bestPriced.priceYen) {
                bestPriced = c;
            }
        }

        if (bestPriced != null) {
            boolean soldOut = containsAny(bestPriced.context, new String[]{
                    "sold out", "out of stock", "notify me when available", "unavailable",
                    "品切れ", "在庫なし", "売り切れ", "売切れ", "完売", "販売終了", "入荷待ち", "在庫切れ"
            });
            boolean preorder = containsAny(bestPriced.context, new String[]{
                    "pre-order", "preorder", "pre order", "presale", "pre-sale", "予約", "予約販売", "予約受付", "発売予定"
            });

            if (soldOut) {
                return new CheckResult(site, CheckResult.SOLD_OUT, bestPriced.priceYen, bestPriced.title,
                        "Risultato specifico trovato, ma sembra sold out/non disponibile.");
            }
            if (bestPriced.priceYen <= maxYen) {
                String note = preorder
                        ? "Risultato specifico trovato nella ricerca, preorder e prezzo sotto soglia. Apri e verifica box sealed."
                        : "Risultato specifico trovato nella ricerca e prezzo sotto soglia. Apri e verifica box sealed.";
                return new CheckResult(site, CheckResult.GOOD, bestPriced.priceYen, bestPriced.title, note);
            }
            return new CheckResult(site, CheckResult.EXPENSIVE, bestPriced.priceYen, bestPriced.title,
                    "Risultato specifico trovato nella ricerca, ma sopra soglia.");
        }

        return new CheckResult(site, CheckResult.MAYBE, null, firstWithoutPrice == null ? pageTitle : firstWithoutPrice.title,
                "Risultato specifico trovato, ma prezzo non letto. Nessuna notifica automatica.");
    }

    private static List<Candidate> findSearchCandidates(Document doc) {
        List<Candidate> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();

        for (Element a : doc.select("a[href]")) {
            StringBuilder titleBuilder = new StringBuilder();
            titleBuilder.append(a.text());
            for (Element img : a.select("img[alt]")) {
                String alt = img.attr("alt");
                if (alt != null && alt.trim().length() > 0) {
                    titleBuilder.append(' ').append(alt);
                }
            }

            String linkTitle = normalize(titleBuilder.toString());
            String href = a.absUrl("href");
            if (!looksLikeExactProduct(linkTitle)) continue;

            String context = linkTitle;
            Element current = a;
            for (int depth = 0; depth < 4 && current != null; depth++) {
                String t = normalize(current.text());
                if (t.length() > context.length() && t.length() < 5000) {
                    context = t;
                }
                current = current.parent();
            }

            if (href.length() == 0) href = linkTitle;
            String key = href + "|" + linkTitle;
            if (seen.contains(key)) continue;
            seen.add(key);

            Integer price = extractLowestReasonablePrice(context);
            out.add(new Candidate(linkTitle, context, price));
        }

        return out;
    }

    private static boolean isSearchPage(String url) {
        String u = url == null ? "" : url.toLowerCase(Locale.ROOT);
        return u.contains("search.rakuten.co.jp")
                || u.contains("shopping.yahoo.co.jp/search")
                || u.contains("amazon.co.jp/s?")
                || u.contains("suruga-ya.jp/search")
                || u.contains("amiami.com") && u.contains("/search/")
                || u.contains("1999.co.jp") && u.contains("search")
                || u.contains("hobby-genki.com") && u.contains("controller=search");
    }

    private static boolean looksLikeExactProduct(String text) {
        if (text == null) return false;
        String upper = text.toUpperCase(Locale.ROOT);
        boolean hasProductName = upper.contains("ORIGINAL ARTWORK COLLECTION")
                || text.contains("オリジナルアートワークコレクション")
                || text.contains("オリジナルアートワーク");
        boolean hasYugioh = upper.contains("YU-GI-OH")
                || upper.contains("YUGIOH")
                || text.contains("遊戯王")
                || text.contains("遊☆戯☆王")
                || text.contains("遊 戯 王")
                || text.contains("遊-戯-王");
        boolean hasBoxSignal = upper.contains("BOX")
                || upper.contains("BOOSTER BOX")
                || text.contains("ボックス")
                || text.contains("1BOX")
                || text.contains("１BOX");
        return hasProductName && (hasYugioh || hasBoxSignal);
    }

    private static String safeMessage(Exception e) {
        return e.getMessage() == null ? "" : e.getMessage();
    }

    private static boolean containsTargetKeyword(String text) {
        String u = text.toUpperCase(Locale.ROOT);
        return u.contains("ORIGINAL ARTWORK COLLECTION")
                || text.contains("オリジナルアートワーク")
                || text.contains("遊戯王 ORIGINAL ARTWORK")
                || text.contains("遊☆戯☆王 ORIGINAL ARTWORK")
                || text.contains("原作絵")
                || text.contains("MANGA-STYLE")
                || text.contains("MANGA STYLE");
    }

    private static boolean containsAny(String text, String[] needles) {
        String lower = text.toLowerCase(Locale.ROOT);
        for (String needle : needles) {
            String n = needle.toLowerCase(Locale.ROOT);
            if (lower.contains(n)) return true;
        }
        return false;
    }

    private static Integer extractLowestReasonablePrice(String text) {
        Matcher matcher = PRICE_PATTERN.matcher(text);
        List<Integer> prices = new ArrayList<>();
        while (matcher.find()) {
            String raw = matcher.group(1) != null ? matcher.group(1) : matcher.group(2);
            if (raw == null) continue;
            try {
                int value = Integer.parseInt(raw.replace(",", ""));
                // Avoid noise: pack retail is 396 yen; focus on box/bundle-like prices. Retail box target is 5,940 yen.
                if (value >= 3000 && value <= 500000) {
                    prices.add(value);
                }
            } catch (NumberFormatException ignored) {
            }
        }
        if (prices.isEmpty()) return null;
        int min = prices.get(0);
        for (int p : prices) min = Math.min(min, p);
        return min;
    }

    private static String normalize(String s) {
        if (s == null) return "";
        return s.replace('\u00A0', ' ')
                .replaceAll("\\s+", " ")
                .trim();
    }

    private static final class Candidate {
        final String title;
        final String context;
        final Integer priceYen;

        Candidate(String title, String context, Integer priceYen) {
            this.title = title;
            this.context = context;
            this.priceYen = priceYen;
        }
    }
}
