package com.salmoit.yugiohwatcher;

public final class CheckResult {
    public static final String GOOD = "PREZZO OK / POSSIBILE PREORDER";
    public static final String EXPENSIVE = "CARO";
    public static final String SOLD_OUT = "SOLD OUT / NON DISPONIBILE";
    public static final String MAYBE = "DA CONTROLLARE";
    public static final String NOT_FOUND = "PRODOTTO NON TROVATO";
    public static final String ERROR = "ERRORE";

    public final Site site;
    public final String status;
    public final Integer priceYen;
    public final String title;
    public final String note;

    public CheckResult(Site site, String status, Integer priceYen, String title, String note) {
        this.site = site;
        this.status = status;
        this.priceYen = priceYen;
        this.title = title;
        this.note = note;
    }

    public boolean shouldNotify() {
        return GOOD.equals(status) || MAYBE.equals(status);
    }

    public String priceText() {
        return priceYen == null ? "Prezzo non rilevato" : "¥" + String.format("%,d", priceYen);
    }
}
