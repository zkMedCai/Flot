package com.salmoit.yugiohwatcher;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class DefaultSites {
    private DefaultSites() {}

    public static List<Site> get() {
        return Collections.unmodifiableList(Arrays.asList(
                new Site("Meccha Japan", "https://meccha-japan.com/en/booster-box/180311-booster-box-original-artwork-collection-yu-gi-oh-ocg.html"),
                new Site("MediaWorld Japan", "https://mediaworld.co.jp/products/13921612000"),
                new Site("AmiAmi ricerca", "https://www.amiami.com/eng/search/list/?s_keywords=Yu-Gi-Oh%20ORIGINAL%20ARTWORK%20COLLECTION"),
                new Site("Hobby Search ricerca", "https://www.1999.co.jp/eng/search?searchkey=Yu-Gi-Oh+ORIGINAL+ARTWORK+COLLECTION"),
                new Site("Hobby Genki ricerca", "https://hobby-genki.com/en/search?controller=search&s=Yu-Gi-Oh+Original+Artwork+Collection"),
                new Site("Amazon JP ricerca", "https://www.amazon.co.jp/s?k=%E9%81%8A%E6%88%AF%E7%8E%8B+ORIGINAL+ARTWORK+COLLECTION+BOX"),
                new Site("Rakuten ricerca", "https://search.rakuten.co.jp/search/mall/%E9%81%8A%E6%88%AF%E7%8E%8B+ORIGINAL+ARTWORK+COLLECTION+BOX/"),
                new Site("Yahoo Shopping JP ricerca", "https://shopping.yahoo.co.jp/search?p=%E9%81%8A%E6%88%AF%E7%8E%8B%20ORIGINAL%20ARTWORK%20COLLECTION%20BOX"),
                new Site("Surugaya ricerca", "https://www.suruga-ya.jp/search?category=&search_word=%E9%81%8A%E6%88%AF%E7%8E%8B+ORIGINAL+ARTWORK+COLLECTION+BOX"),
                new Site("GRIMSHOP", "https://grimtcd.com/products/%E3%82%A2%E3%82%B8%E3%82%A2%E7%89%88-%E9%81%8A-%E6%88%AF-%E7%8E%8B-original-artwork-collection-%E4%BB%AE"),
                new Site("Platinum Store", "https://platinumstore.stores.jp/items/6a02de1be843872b92b97277")
        ));
    }

    public static List<Site> withCustom(List<String> customUrls) {
        ArrayList<Site> sites = new ArrayList<>(get());
        for (String url : customUrls) {
            if (url != null && url.trim().startsWith("http")) {
                sites.add(new Site("Custom", url.trim()));
            }
        }
        return sites;
    }
}
