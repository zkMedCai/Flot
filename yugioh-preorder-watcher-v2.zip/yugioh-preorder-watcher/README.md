# Yu-Gi-Oh! Preorder Watcher

App Android nativa per controllare siti giapponesi alla ricerca di **Yu-Gi-Oh! OCG ORIGINAL ARTWORK COLLECTION**.

## Cosa fa

- Controlla una lista base di siti: Meccha Japan, MediaWorld JP, AmiAmi, Hobby Search, Hobby Genki, Amazon JP, Rakuten, Yahoo Shopping JP, Surugaya, GRIMSHOP, Platinum Store.
- Cerca keyword del prodotto: `ORIGINAL ARTWORK COLLECTION`, `オリジナルアートワーク`, `遊戯王 ORIGINAL ARTWORK`, `MANGA-STYLE`.
- Estrae prezzi in yen dalle pagine HTML.
- Segnala se trova un prezzo sotto la soglia impostata, default `8000¥`.
- Permette di aggiungere URL custom dall'app.
- Ha auto-check in background ogni 6 ore con notifica Android.

## Limiti importanti

Alcuni siti possono bloccare richieste automatiche, usare contenuto dinamico JavaScript o mostrare prezzi diversi in base alla regione. L'app è pensata come alert rapido: quando compare un risultato buono, apri sempre la pagina e verifica manualmente che sia davvero **box sigillato** e non pack sfusi.

## Build con Android Studio

1. Apri la cartella del progetto in Android Studio.
2. Aspetta il Gradle sync.
3. Vai su `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. Installa l'APK debug sul telefono.

## Build automatica con GitHub Actions

1. Crea un repository GitHub e carica questa cartella.
2. Vai nella tab `Actions`.
3. Avvia il workflow `Build Debug APK`.
4. Scarica l'artifact `YuGiOhPreorderWatcher-debug-apk`.

## Prezzo consigliato

Il retail box target è circa **5.940¥**. La soglia consigliata nell'app è **8.000¥** o massimo **9.000¥** se vuoi essere più elastico.

## v2 note
- Search pages such as Rakuten/Amazon/Yahoo are now checked in strict mode: the app only alerts when a product result/card itself contains `ORIGINAL ARTWORK COLLECTION`, not just because the search query is in the page title.
- Automatic notifications are sent only for `PREZZO OK / POSSIBILE PREORDER`, not for ambiguous `DA CONTROLLARE` results.
