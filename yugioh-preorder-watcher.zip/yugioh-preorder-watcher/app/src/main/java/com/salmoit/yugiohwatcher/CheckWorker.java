package com.salmoit.yugiohwatcher;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CheckWorker extends Worker {
    public static final String WORK_NAME = "yugioh_preorder_auto_check";
    private static final String CHANNEL_ID = "preorder_alerts";

    public CheckWorker(Context context, WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @Override
    public Result doWork() {
        Context context = getApplicationContext();
        SharedPreferences prefs = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        int maxYen = prefs.getInt(MainActivity.KEY_MAX_YEN, MainActivity.DEFAULT_MAX_YEN);
        Set<String> customSet = prefs.getStringSet(MainActivity.KEY_CUSTOM_URLS, new HashSet<>());
        List<Site> sites = DefaultSites.withCustom(new ArrayList<>(customSet));

        List<CheckResult> alerts = new ArrayList<>();
        for (Site site : sites) {
            CheckResult result = SiteChecker.check(site, maxYen);
            if (result.shouldNotify()) {
                alerts.add(result);
            }
            try {
                Thread.sleep(800);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return Result.retry();
            }
        }

        if (!alerts.isEmpty()) {
            sendNotification(context, alerts, maxYen);
        }
        return Result.success();
    }

    private void sendNotification(Context context, List<CheckResult> alerts, int maxYen) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Preorder alerts", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Alert per preorder Yu-Gi-Oh sotto soglia");
            manager.createNotificationChannel(channel);
        }

        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        StringBuilder body = new StringBuilder();
        int limit = Math.min(alerts.size(), 3);
        for (int i = 0; i < limit; i++) {
            CheckResult r = alerts.get(i);
            body.append(r.site.name).append(" - ").append(r.priceText());
            if (i < limit - 1) body.append("\n");
        }
        if (alerts.size() > limit) {
            body.append("\n+").append(alerts.size() - limit).append(" altri risultati");
        }

        Notification.BigTextStyle style = new Notification.BigTextStyle().bigText(body.toString());
        Notification notification = new Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Possibile preorder Yu-Gi-Oh trovato")
                .setContentText(alerts.size() + " risultato/i sotto o vicino soglia ¥" + String.format("%,d", maxYen))
                .setStyle(style)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build();

        manager.notify(260926, notification);
    }
}
