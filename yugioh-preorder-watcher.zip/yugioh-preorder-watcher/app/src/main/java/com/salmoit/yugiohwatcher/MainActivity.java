package com.salmoit.yugiohwatcher;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    public static final String PREFS = "watcher_prefs";
    public static final String KEY_MAX_YEN = "max_yen";
    public static final String KEY_CUSTOM_URLS = "custom_urls";
    public static final String KEY_AUTO_ENABLED = "auto_enabled";
    public static final int DEFAULT_MAX_YEN = 8000;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private SharedPreferences prefs;
    private EditText maxYenInput;
    private EditText customUrlInput;
    private Button checkButton;
    private Button autoButton;
    private TextView statusText;
    private LinearLayout resultsContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        requestNotificationPermissionIfNeeded();
        buildUi();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }

    private void buildUi() {
        ScrollView scrollView = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(30));
        scrollView.addView(root);

        TextView title = new TextView(this);
        title.setText("Yu-Gi-Oh! Preorder Watcher");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(0xFF111827);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Controlla i siti giapponesi per ORIGINAL ARTWORK COLLECTION e segnala prezzi sotto soglia.");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF4B5563);
        subtitle.setPadding(0, dp(6), 0, dp(14));
        root.addView(subtitle);

        TextView priceLabel = label("Soglia massima box in yen");
        root.addView(priceLabel);

        maxYenInput = new EditText(this);
        maxYenInput.setSingleLine(true);
        maxYenInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        maxYenInput.setText(String.valueOf(prefs.getInt(KEY_MAX_YEN, DEFAULT_MAX_YEN)));
        maxYenInput.setHint("8000");
        root.addView(maxYenInput, matchWrap());

        LinearLayout buttonRow = new LinearLayout(this);
        buttonRow.setOrientation(LinearLayout.HORIZONTAL);
        buttonRow.setGravity(Gravity.CENTER_VERTICAL);
        buttonRow.setPadding(0, dp(12), 0, dp(8));
        root.addView(buttonRow);

        checkButton = new Button(this);
        checkButton.setText("Controlla ora");
        checkButton.setOnClickListener(v -> runCheckNow());
        buttonRow.addView(checkButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        autoButton = new Button(this);
        updateAutoButtonText();
        autoButton.setOnClickListener(v -> toggleAutoCheck());
        LinearLayout.LayoutParams autoParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        autoParams.setMargins(dp(8), 0, 0, 0);
        buttonRow.addView(autoButton, autoParams);

        TextView customLabel = label("Aggiungi URL custom da controllare");
        customLabel.setPadding(0, dp(10), 0, 0);
        root.addView(customLabel);

        customUrlInput = new EditText(this);
        customUrlInput.setSingleLine(true);
        customUrlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        customUrlInput.setHint("https://...");
        root.addView(customUrlInput, matchWrap());

        LinearLayout customRow = new LinearLayout(this);
        customRow.setOrientation(LinearLayout.HORIZONTAL);
        customRow.setPadding(0, dp(8), 0, dp(8));
        root.addView(customRow);

        Button addButton = new Button(this);
        addButton.setText("Aggiungi");
        addButton.setOnClickListener(v -> addCustomUrl());
        customRow.addView(addButton, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button resetButton = new Button(this);
        resetButton.setText("Reset custom");
        resetButton.setOnClickListener(v -> resetCustomUrls());
        LinearLayout.LayoutParams resetParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        resetParams.setMargins(dp(8), 0, 0, 0);
        customRow.addView(resetButton, resetParams);

        statusText = new TextView(this);
        statusText.setTextSize(13);
        statusText.setTextColor(0xFF374151);
        statusText.setText("Pronto. Siti base: " + DefaultSites.get().size() + ". Custom: " + getCustomUrls().size() + ".");
        statusText.setPadding(0, dp(8), 0, dp(10));
        root.addView(statusText);

        resultsContainer = new LinearLayout(this);
        resultsContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(resultsContainer);

        setContentView(scrollView);
    }

    private TextView label(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextColor(0xFF111827);
        return tv;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void runCheckNow() {
        int maxYen = parseMaxYen();
        prefs.edit().putInt(KEY_MAX_YEN, maxYen).apply();

        List<Site> sites = DefaultSites.withCustom(new ArrayList<>(getCustomUrls()));
        resultsContainer.removeAllViews();
        checkButton.setEnabled(false);
        statusText.setText("Controllo " + sites.size() + " siti... prezzo max ¥" + String.format("%,d", maxYen));

        executor.submit(() -> {
            int hits = 0;
            for (int i = 0; i < sites.size(); i++) {
                Site site = sites.get(i);
                CheckResult result = SiteChecker.check(site, maxYen);
                if (result.shouldNotify()) hits++;
                int progress = i + 1;
                int finalHits = hits;
                runOnUiThread(() -> {
                    addResultCard(result);
                    statusText.setText("Controllati " + progress + "/" + sites.size() + " siti. Alert: " + finalHits + ".");
                });
                try {
                    Thread.sleep(650);
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            runOnUiThread(() -> {
                checkButton.setEnabled(true);
                Toast.makeText(this, "Check completato", Toast.LENGTH_SHORT).show();
            });
        });
    }

    private void addResultCard(CheckResult result) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(makeBackground(statusColor(result.status)));
        card.setClickable(true);
        card.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(result.site.url)));
            } catch (Exception e) {
                Toast.makeText(this, "Impossibile aprire URL", Toast.LENGTH_SHORT).show();
            }
        });

        TextView name = new TextView(this);
        name.setText(result.site.name + "  •  " + result.status);
        name.setTextSize(15);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setTextColor(0xFF111827);
        card.addView(name);

        TextView price = new TextView(this);
        price.setText(result.priceText());
        price.setTextSize(14);
        price.setTextColor(0xFF111827);
        price.setPadding(0, dp(4), 0, 0);
        card.addView(price);

        String compactTitle = result.title == null || result.title.isEmpty() ? "Titolo non letto" : result.title;
        TextView details = new TextView(this);
        details.setText(compactTitle + "\n" + result.note + "\n" + result.site.url);
        details.setTextSize(12);
        details.setTextColor(0xFF374151);
        details.setPadding(0, dp(4), 0, 0);
        card.addView(details);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, dp(10));
        resultsContainer.addView(card, params);
    }

    private int statusColor(String status) {
        if (CheckResult.GOOD.equals(status)) return 0xFFD1FAE5;
        if (CheckResult.MAYBE.equals(status)) return 0xFFDBEAFE;
        if (CheckResult.EXPENSIVE.equals(status)) return 0xFFFFEDD5;
        if (CheckResult.SOLD_OUT.equals(status)) return 0xFFE5E7EB;
        if (CheckResult.ERROR.equals(status)) return 0xFFFEE2E2;
        return 0xFFF3F4F6;
    }

    private GradientDrawable makeBackground(int color) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(14));
        drawable.setStroke(dp(1), 0xFFE5E7EB);
        return drawable;
    }

    private int parseMaxYen() {
        try {
            int value = Integer.parseInt(maxYenInput.getText().toString().trim());
            if (value < 3000) return 3000;
            if (value > 100000) return 100000;
            return value;
        } catch (Exception e) {
            return DEFAULT_MAX_YEN;
        }
    }

    private void addCustomUrl() {
        String url = customUrlInput.getText().toString().trim();
        if (!url.startsWith("https://") && !url.startsWith("http://")) {
            Toast.makeText(this, "Inserisci un URL completo con https://", Toast.LENGTH_SHORT).show();
            return;
        }
        Set<String> urls = new HashSet<>(getCustomUrls());
        urls.add(url);
        prefs.edit().putStringSet(KEY_CUSTOM_URLS, urls).apply();
        customUrlInput.setText("");
        statusText.setText("URL aggiunto. Siti base: " + DefaultSites.get().size() + ". Custom: " + urls.size() + ".");
    }

    private void resetCustomUrls() {
        prefs.edit().remove(KEY_CUSTOM_URLS).apply();
        statusText.setText("URL custom rimossi. Siti base: " + DefaultSites.get().size() + ".");
    }

    private Set<String> getCustomUrls() {
        return prefs.getStringSet(KEY_CUSTOM_URLS, new HashSet<>());
    }

    private void toggleAutoCheck() {
        boolean enabled = prefs.getBoolean(KEY_AUTO_ENABLED, false);
        if (enabled) {
            WorkManager.getInstance(this).cancelUniqueWork(CheckWorker.WORK_NAME);
            prefs.edit().putBoolean(KEY_AUTO_ENABLED, false).apply();
            Toast.makeText(this, "Auto-check disattivato", Toast.LENGTH_SHORT).show();
        } else {
            scheduleAutoCheck();
            prefs.edit().putBoolean(KEY_AUTO_ENABLED, true).apply();
            Toast.makeText(this, "Auto-check ogni 6 ore attivato", Toast.LENGTH_SHORT).show();
        }
        updateAutoButtonText();
    }

    private void scheduleAutoCheck() {
        int maxYen = parseMaxYen();
        prefs.edit().putInt(KEY_MAX_YEN, maxYen).apply();
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(CheckWorker.class, 6, TimeUnit.HOURS)
                .addTag(CheckWorker.WORK_NAME)
                .build();
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                CheckWorker.WORK_NAME,
                ExistingPeriodicWorkPolicy.REPLACE,
                request
        );
    }

    private void updateAutoButtonText() {
        if (autoButton != null) {
            autoButton.setText(prefs.getBoolean(KEY_AUTO_ENABLED, false) ? "Auto ON" : "Auto 6h OFF");
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
